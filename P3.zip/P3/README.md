FRONTEND NANODEGREE - PROJECT 3 - ARCADE GAME - FROGGER CLONE
=============================================================
This project was a recreation of the classic arcade game, Frogger.
More functionality will be added to this rendition in the months to come.


INSTRUCTIONS
============
GOAL: reach the water before the bugs eat your player
HOW TO PLAY: use the up arrow to move up
			 use the down arrow to move down
			 use the left arrow to move left
			 use the right arrow to move right
If you reach the water you win and the game resets.
If you are eaten by a bug you lose and the game resets.
Happy Dodging!


INSTALLATION
============
Click index.html and enjoy the app :)


SUPPORT
=======
If you're having issues please email Shaun at shauncox44@gmail.com